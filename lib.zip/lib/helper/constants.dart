
class Constants{

  static String myName = "";
}
